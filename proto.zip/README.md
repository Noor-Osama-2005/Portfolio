
  # Elegant Portfolio Website

  This is a code bundle for Elegant Portfolio Website. The original project is available at https://www.figma.com/design/FO7ug4lmpNX6kSzw4YT47n/Elegant-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  